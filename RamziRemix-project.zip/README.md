# Ramzi Remix v1.3
1. ارفع محتويات هذا المجلد كاملة إلى مستودع GitHub جديد (مع مجلد .github).
2. افتح تبويب Actions ثم Build APK ثم Run workflow.
3. بعد انتهاء البناء نزّل Ramzi-Remix-debug من قسم Artifacts.
4. احذف النسخة القديمة من التطبيق قبل التثبيت (التوقيع مختلف).
