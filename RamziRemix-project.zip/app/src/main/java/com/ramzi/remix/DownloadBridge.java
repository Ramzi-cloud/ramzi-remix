package com.ramzi.remix;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.io.OutputStream;

public class DownloadBridge {
    private final Activity act;
    private OutputStream os;

    public DownloadBridge(Activity a) { act = a; }

    @JavascriptInterface
    public boolean begin(String name, String mime) {
        try {
            if (Build.VERSION.SDK_INT < 29) return false; // يتطلب أندرويد 10 أو أحدث
            ContentResolver r = act.getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, name);
            v.put(MediaStore.Downloads.MIME_TYPE, mime);
            v.put(MediaStore.Downloads.RELATIVE_PATH, "Download");
            Uri uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return false;
            os = r.openOutputStream(uri);
            return os != null;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public void chunk(String b64) {
        try { os.write(Base64.decode(b64, Base64.DEFAULT)); } catch (Exception e) { }
    }

    @JavascriptInterface
    public void end() {
        try { os.close(); } catch (Exception e) { }
        act.runOnUiThread(() ->
            Toast.makeText(act, "تم الحفظ في التنزيلات", Toast.LENGTH_SHORT).show());
    }
}
